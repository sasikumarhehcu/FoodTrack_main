subprojects {
    repositories {
        google()
        mavenCentral()
    }
}
